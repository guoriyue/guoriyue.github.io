# TinyTriton: build a compiler, one step at a time

A tutorial series for Python programmers with no compiler background.
**Currently published: Step 1 — source code to instructions.**
Later lessons and implementations will arrive alongside their posts.

- [Series overview](https://guoriyue.github.io/blog/tinytriton-series/)
- [Step 1 blog](https://guoriyue.github.io/blog/tinytriton-step-1/)
- [Step 1 tutorial](steps/step01-triton-ir.md)
- [Exercise](https://github.com/guoriyue/tiny-triton/blob/main/problems/step01.py)
- [Reference implementation — try the exercise first](https://github.com/guoriyue/tiny-triton/blob/main/solutions/step01.py)

## Start

The development repository is currently private. Blog readers can download the
[standalone Step 1 package](https://guoriyue.github.io/downloads/tinytriton-step-1.zip),
extract it, and run the installation commands below from `tinytriton-step-1/`,
skipping the two Git commands. The public repository will be shared later.

Python 3.10 or newer is enough. No GPU, CUDA, LLVM, or Triton installation is needed.

```bash
git clone https://github.com/guoriyue/tiny-triton.git
cd tiny-triton
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
tinytriton check step01
```

The unfinished exercise raises `NotImplementedError`; that is the expected starting
point. Implement its three TODOs using the tutorial, then rerun the check.
On Windows, activate the environment with `.venv\Scripts\activate` instead.

After attempting the exercise:

```bash
tinytriton check step01 --solution
```

The checks cover representation and dependencies, not execution on real arrays.
Execution will be the next lesson. The package contains only the sample source and
check runner; the compiler you write lives in `problems/step01.py`.

This is an educational Triton-style language, not the official Triton compiler.
The default branch contains the current lesson release; earlier Git history is
retained. License: [MIT](https://github.com/guoriyue/tiny-triton/blob/main/LICENSE).
